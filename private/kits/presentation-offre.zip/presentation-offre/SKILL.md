---
name: presentation-offre
description: Prépare la présentation d'un prestataire en 30 secondes, en texte et en note vocale. À utiliser quand l'utilisateur veut se présenter ou présenter son offre à un futur client.
---

# Présentation en 30 secondes

Quand l'utilisateur veut présenter son activité, préparez trois formats courts.

## Avant d'écrire
Il vous faut : ce que fait l'utilisateur, pour qui, ce qui le distingue vraiment, et comment le joindre. Une réalisation vraie est utile, sans nom de client. S'il manque le métier ou le public, posez une seule question.

## Ce que vous livrez
1. Un texte de 4 lignes au plus pour WhatsApp, qui commence par une salutation.
2. Le script d'une note vocale de 30 secondes : 70 à 80 mots, écrits comme on parle, en phrases courtes.
3. Une phrase de 100 caractères au plus pour le statut ou la page.

## Règles
- Vouvoyez le lecteur. Texte simple, sans astérisque ni titre.
- Aucun client, aucun chiffre, aucune récompense inventés.
- Pas de superlatif : ni « le meilleur », ni « numéro 1 ».
- Si l'utilisateur ne donne aucune réalisation, n'en citez aucune.
- Chaque format finit par une invitation simple : « Écrivez-moi pour un devis. »
