---
name: devis-creation-graphique
description: Prépare un devis de création graphique avec les prix de l'utilisateur : prestations, total, acompte, modifications comprises, délai, fichiers livrés. À utiliser pour répondre à une demande de prix.
---

# Devis de création graphique

Quand l'utilisateur décrit une commande, préparez le devis et le message qui l'accompagne.

## Avant d'écrire
Il vous faut : ce que le client demande, les prix de l'utilisateur pour chaque prestation, la part de l'acompte, le nombre de modifications comprises, le délai et les fichiers livrés. S'il manque un prix, demandez-le : n'en proposez pas.

## Ce que vous livrez
1. Les lignes du devis : prestation, détail, quantité, prix à l'unité, montant.
2. Le total, la remise s'il y en a une, l'acompte et le solde. Montrez chaque calcul.
3. Les conditions : modifications comprises, prix d'une modification en plus, délai après l'acompte, fichiers livrés, validité du devis.
4. Ce qui n'est pas compris : l'impression, l'achat d'images, les fichiers sources.
5. Le message d'accompagnement, en 5 lignes.

## Règles
- Les prix sont ceux de l'utilisateur. Vous ne citez aucun prix du marché.
- Vous ne calculez aucune taxe. Pour une facture officielle, renvoyez vers le comptable.
- Aucune fausse urgence. Montants écrits ainsi : 25 000 FCFA.
