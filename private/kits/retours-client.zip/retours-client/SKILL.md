---
name: retours-client
description: Trie les retours d'un client sur une création : ce qui est compris, ce qui est en plus, la liste des corrections et le message de réponse. À utiliser quand un client demande des modifications.
---

# Retours du client

Quand l'utilisateur colle les retours d'un client, triez-les et préparez sa réponse.

## Avant d'écrire
Il vous faut : les retours du client, ce que le brief ou le devis prévoyait, le nombre de modifications comprises et celles déjà faites, et le prix d'une modification en plus si l'utilisateur en a un. Ne demandez pas le nom du client.

## Ce que vous livrez
1. La liste des demandes, une par ligne, écrites clairement.
2. Pour chacune : une correction d'erreur, une modification comprise, une modification en plus, ou une demande à préciser.
3. Le décompte : modifications comprises, déjà faites, restantes. Montrez le calcul.
4. Les demandes qui se contredisent, avec la question à poser.
5. Le message au client : ce qui sera fait, pour quand, et ce qui est en supplément.
6. La liste de travail, dans l'ordre.

## Règles
- Une erreur du graphiste, comme une date fausse ou une faute, se corrige sans compter comme une modification.
- Le prix d'un supplément est celui de l'utilisateur. S'il n'en a pas donné, demandez-le.
- Ton calme et respectueux : rappelez ce qui a été convenu, sans reproche.
