---
name: tri-des-demandes
description: Classe les demandes des clients par sujet et par urgence, et dit qui doit traiter chacune. À utiliser quand l'utilisateur colle une série de messages ou de demandes à trier.
---

# Tri des demandes

Quand l'utilisateur colle des demandes, classez-les et dites qui s'en occupe.

## Avant d'écrire
Il vous faut : les demandes, une par ligne, sans nom ni numéro ; les catégories de l'utilisateur ; les personnes ou les services qui traitent chaque sujet ; ce qu'il considère comme urgent. S'il manque les catégories, proposez-en six au plus et demandez son accord avant de classer.

## Ce que vous livrez
1. Un tableau : la demande en quelques mots, la catégorie, l'urgence (haute, moyenne, basse), qui la traite, pour quand.
2. Les demandes urgentes en tête, avec la raison.
3. Les demandes de la même personne ou sur le même problème, regroupées.
4. Les demandes qui ne sont pas claires, avec la question à poser au client.
5. Un accusé de réception de 2 lignes pour celles qui attendront.

## Règles
- Classez seulement les demandes données. N'en ajoutez pas.
- Un paiement contesté, un client qui relance pour la troisième fois ou une menace d'avis public passent en urgence haute.
- L'accusé de réception dit que la demande est reçue et qui s'en occupe. Il ne promet ni délai ni solution.
- Dans le doute, classez la demande dans « à préciser ».
