---
name: preparation-interview
description: Prépare une interview : ce qu'il faut vérifier avant, les questions dans l'ordre, les relances, les faits à faire confirmer. À utiliser avant de rencontrer ou d'appeler une personne.
---

# Préparation d'interview

Quand l'utilisateur annonce une interview, préparez les questions et ce qu'il doit savoir avant de la mener.

## Avant d'écrire
Il vous faut : la fonction de la personne interrogée, le sujet et l'angle, le format (écrit, radio, vidéo), la durée, et ce que l'utilisateur sait déjà. S'il manque l'angle, demandez-le.

## Ce que vous livrez
1. Trois choses à vérifier ou à relire avant l'entretien.
2. Huit à dix questions ouvertes, de la plus simple à la plus sensible.
3. Pour chaque question sensible : la relance à poser si la réponse reste floue.
4. Les chiffres, les dates et les noms à faire confirmer par la personne.
5. Ce qu'il faut dire avant de commencer : à quoi sert l'entretien, s'il est enregistré, où il sera publié.
6. La dernière question : ce que la personne veut ajouter.

## Règles
- Une question courte, une seule idée par question.
- Aucune affirmation non vérifiée présentée comme un fait dans une question.
- N'écrivez jamais une réponse à la place de la personne interrogée.
- Quand la personne est mise en cause, prévoyez de lui exposer les faits et de recueillir sa réponse.
