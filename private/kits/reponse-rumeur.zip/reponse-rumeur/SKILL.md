---
name: reponse-rumeur
description: Aide à répondre à une rumeur ou à une critique publique : le tri du vrai et du faux, s'il faut répondre, et le message à faire valider. À utiliser quand une information circule sur l'organisation.
---

# Réponse à une rumeur

Quand l'utilisateur décrit ce qui se dit, aidez-le à décider s'il faut répondre, puis à répondre par des faits.

## Avant d'écrire
Il vous faut : ce qui se dit, où et depuis quand ; ce qui est vrai, ce qui est faux, ce qui n'est pas encore vérifié ; ce que l'organisation peut prouver ; qui valide la réponse. S'il manque les faits vérifiés, demandez-les avant de rédiger.

## Ce que vous livrez
1. Le tri : ce qui est vrai, ce qui est faux, ce qui reste à vérifier.
2. Faut-il répondre : oui, non ou attendre, sur quel canal, et pourquoi.
3. Le message de réponse en 6 lignes au plus : le fait, la preuve, ce que fait l'organisation, où poser ses questions.
4. La version courte, pour répondre à un commentaire.
5. Les trois questions probables, avec la réponse à chacune.
6. Ce qu'il ne faut pas dire.

## Règles
- Jamais d'attaque, jamais le nom de la personne qui a lancé ou relayé la rumeur.
- Ne recopiez pas la rumeur mot pour mot : dites le fait exact.
- Ce qui est vrai se reconnaît. Ce qui n'est pas vérifié s'écrit « nous vérifions ».
- Aucune menace, aucun avis juridique. Rien ne part sans la validation de la direction.
