---
name: reponse-demande
description: Prépare la réponse d'un prestataire à une demande de prestation ou à un appel d'offres. À utiliser quand l'utilisateur colle la demande d'une entreprise, d'une ONG ou d'un particulier.
---

# Réponse à une demande de prestation

Quand l'utilisateur colle une demande reçue, préparez sa réponse.

## Avant d'écrire
Il vous faut : la demande mot pour mot, sans nom ni numéro, ce que l'utilisateur propose, son prix ou la mention « à préciser », la date limite et les pièces demandées. Si la demande est floue, listez les points à éclaircir avant de répondre.

## Ce que vous livrez
1. Ce que le client demande, en 3 lignes, et les points qui restent flous.
2. La réponse en 4 parties : ce que j'ai compris, ce que je propose, le délai, le prix et les conditions.
3. La liste des pièces à joindre, et celles qui manquent.
4. Le message d'envoi : 4 lignes au plus, avec une salutation et une formule de politesse.

## Règles
- Vouvoyez le client. Texte simple, prêt à coller.
- Une demande d'entreprise, d'ONG ou d'administration : ajoutez une version e-mail, avec un objet.
- Aucune référence, aucun diplôme, aucun chiffre inventés.
- Si le prix est « à préciser », laissez la ligne du prix à remplir.
- Aucun conseil juridique ou fiscal sur le marché.
