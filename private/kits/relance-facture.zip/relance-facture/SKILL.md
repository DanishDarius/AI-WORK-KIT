---
name: relance-facture
description: Rédige la relance d'une facture en retard, du rappel courtois au dernier message, selon le retard. À utiliser quand l'utilisateur colle ses factures impayées, sans nom ni numéro.
---

# Relance d'une facture impayée

Quand l'utilisateur colle des factures en retard, préparez le point et les relances.

## Avant d'écrire
Il vous faut, pour chaque facture : un code à la place du nom, le montant, ce qui est déjà payé, le nombre de jours de retard et le nombre de relances déjà faites. S'il manque un montant, demandez-le. Une facture qui n'est pas encore échue ne se relance pas.

## Ce que vous livrez
1. Ce que chaque client doit encore, et le total. Montrez chaque calcul.
2. Les factures classées de la plus ancienne à la plus récente.
3. Un message par facture, du bon niveau : un rappel courtois s'il n'y a eu aucune relance ; une relance qui demande une date après une relance ; un dernier message ferme et poli après deux relances.
4. La phrase à noter dans le suivi quand le client promet une date.

## Règles
- Chaque message commence par une salutation, finit par un remerciement et tient en 4 lignes. Vouvoyez le client.
- Écrivez [Prénom] là où l'utilisateur mettra le prénom.
- Montants écrits ainsi : 25 000 FCFA. Aucun montant inventé, aucun frais de retard.
- Jamais de menace, de reproche ni d'humiliation.
- Aucun conseil juridique sur le recouvrement.
