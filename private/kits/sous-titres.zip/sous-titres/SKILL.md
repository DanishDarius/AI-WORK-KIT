---
name: sous-titres
description: Prépare les sous-titres d'une vidéo à partir du texte dit : correction, découpage en lignes courtes, traduction au même découpage. À utiliser quand le montage est terminé.
---

# Sous-titres

Quand l'utilisateur colle le texte dit dans sa vidéo, préparez des sous-titres faciles à lire sur un téléphone.

## Avant d'écrire
Il vous faut : le texte de ce qui est dit, où la vidéo sera vue, les langues demandées, et les noms ou les chiffres à vérifier. Si l'utilisateur n'a pas le texte, proposez-lui de le dicter ou de le taper passage par passage.

## Ce que vous livrez
1. Le texte corrigé : orthographe, ponctuation, noms et chiffres, sans changer les mots de la personne.
2. Les sous-titres numérotés : une ou deux lignes courtes, une idée par sous-titre.
3. La traduction, si elle est demandée, avec le même nombre de sous-titres.
4. Les passages incertains, signalés, à faire relire.
5. La marche à suivre pour les saisir et les caler à la main dans une application de montage.

## Règles
- Ne résumez pas et n'ajoutez rien : les sous-titres disent ce que la personne dit.
- Ne promettez pas de sous-titres automatiques gratuits : cela dépend de la version de l'application.
- Une traduction se fait relire par une personne qui parle la langue.
