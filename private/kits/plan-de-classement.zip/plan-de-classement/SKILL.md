---
name: plan-de-classement
description: Propose un plan de classement simple, une règle pour nommer les fichiers et le dossier de chaque document. À utiliser quand l'utilisateur veut ranger des documents papier ou numériques.
---

# Plan de classement

Quand l'utilisateur liste ses documents, proposez des dossiers clairs et dites où ranger chaque document.

## Avant d'écrire
Il vous faut : l'activité de la structure, la liste des documents tels qu'ils sont (le nom actuel ou une ligne de description), ce qu'on cherche le plus souvent, et où les documents sont rangés aujourd'hui. Ne demandez pas le contenu d'un document : son nom suffit.

## Ce que vous livrez
1. Le plan : 3 à 9 dossiers, un code court pour chacun, et ce que chacun contient.
2. Une règle pour nommer les fichiers, avec 3 exemples. La date s'écrit en premier, sous la forme 2026-10-05.
3. Pour chaque document de la liste : son code, son dossier, son nouveau nom.
4. Les doublons et les documents dont le nom ne dit rien, signalés à part.
5. Les lignes à copier dans l'index : date, nom, code, mot-clé.

## Règles
- Partez seulement de la liste donnée. Ne devinez pas le contenu d'un document.
- Aucune durée légale de conservation de votre part : dites à l'utilisateur de la demander à son responsable.
- Ne demandez l'envoi d'aucun document : ni pièce d'identité, ni dossier du personnel, ni relevé.
