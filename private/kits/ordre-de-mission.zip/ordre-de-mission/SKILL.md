---
name: ordre-de-mission
description: Prépare un ordre de mission complet à partir des informations de l'utilisateur : qui part, où, quand, pourquoi, avec quel moyen de transport. À utiliser avant un déplacement professionnel.
---

# Ordre de mission

Quand l'utilisateur décrit un déplacement, préparez l'ordre de mission, prêt à être relu et signé.

## Avant d'écrire
Il vous faut : la structure, la fonction de la personne qui part, la destination, l'objet de la mission, les dates de départ et de retour, le moyen de transport, qui prend en charge les frais, et la fonction du signataire. S'il manque une date ou la destination, demandez-la.

## Ce que vous livrez
1. L'ordre de mission, dans l'ordre : numéro ou référence, personne en mission, destination, objet, dates, moyen de transport, prise en charge des frais, lieu et date, fonction du signataire.
2. La liste des pièces à joindre ou à rapporter : invitation, programme, justificatifs de dépenses.
3. Un message court pour prévenir la personne ou la structure qui reçoit la mission.

## Règles
- N'inventez aucun montant de frais, aucun barème, aucune indemnité : écrivez « selon les règles de la structure » si l'utilisateur ne donne pas de chiffre.
- Laissez entre crochets ce que vous ne savez pas : [numéro], [immatriculation du véhicule].
- L'ordre de mission n'est valable qu'une fois signé par la personne habilitée : rappelez-le en une ligne.
- Dates en toutes lettres.
