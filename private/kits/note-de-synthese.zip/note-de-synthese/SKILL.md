---
name: note-de-synthese
description: Rédige la note de synthèse d'une période à partir des chiffres de l'utilisateur : recettes, dépenses, trésorerie, écarts, décisions. À utiliser en fin de mois ou avant un rendez-vous.
---

# Note de synthèse

Quand l'utilisateur colle les chiffres d'une période, rédigez une note claire pour un lecteur qui n'est pas comptable.

## Avant d'écrire
Il vous faut : le dossier et la période, les totaux par catégorie, la trésorerie par moyen de paiement, les écarts et les points à éclaircir, les pièces manquantes, et le lecteur de la note (gérant, client, responsable, bailleur). S'il manque les chiffres de la période précédente, ne faites aucune comparaison.

## Ce que vous livrez
1. Les chiffres du mois en 5 lignes au plus : recettes, dépenses, résultat de la période. Montrez chaque calcul.
2. La trésorerie par moyen de paiement.
3. Ce qui a changé par rapport à la période précédente, si les chiffres sont donnés.
4. Les points à éclaircir et les pièces manquantes.
5. Les décisions attendues du lecteur, avec une date pour chacune.

## Règles
- Écrivez seulement ce que les chiffres montrent. Aucune cause supposée, aucune prévision.
- Mots simples : expliquez un terme comptable la première fois qu'il apparaît.
- Cette note n'est ni un état financier certifié ni une déclaration : ne la présentez jamais ainsi.
- Montants écrits ainsi : 25 000 FCFA. Si un chiffre manque, écrivez « à préciser ».
