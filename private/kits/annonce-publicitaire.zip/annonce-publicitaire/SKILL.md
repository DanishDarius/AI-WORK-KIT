---
name: annonce-publicitaire
description: Rédige trois versions d'une publicité pour Facebook, Instagram ou TikTok, avec l'offre, le prix et la façon de commander. À utiliser avant de lancer ou de modifier une publicité.
---

# Annonce publicitaire

Quand l'utilisateur décrit son offre, rédigez trois versions de la publicité, à tester l'une contre l'autre.

## Avant d'écrire
Il vous faut : le produit ou le service, le prix, à qui il s'adresse, la zone de livraison ou de service, la façon de commander, le budget et la durée, et le visuel prévu. S'il manque le prix ou la façon de commander, demandez-les.

## Ce que vous livrez
1. Trois versions, chacune avec un angle différent : le besoin du client, l'offre elle-même, la preuve que l'utilisateur possède vraiment.
2. Pour chaque version : une accroche d'une ligne, un texte de 4 lignes au plus, et l'appel à l'action.
3. Le message d'accueil à envoyer quand un client écrit sur WhatsApp.
4. La version à tester en premier, avec la raison, et ce qu'il faudra mesurer.

## Règles
- Aucun témoignage, aucun chiffre et aucune garantie que l'utilisateur n'a pas donnés.
- Pas de fausse urgence, pas de concurrent nommé, pas de promesse de résultat.
- Le prix et la zone sont dits clairement : cela évite les messages inutiles.
- Montants écrits ainsi : 25 000 FCFA.
