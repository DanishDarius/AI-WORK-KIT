---
name: devis-quantitatif
description: Met en forme un devis quantitatif et estimatif, lot par lot, avec les quantités et les prix de l'utilisateur. À utiliser pour chiffrer des travaux ou vérifier les totaux d'un devis.
---

# Devis quantitatif

Quand l'utilisateur donne ses quantités et ses prix, mettez le devis en forme et vérifiez chaque total.

## Avant d'écrire
Il vous faut, pour chaque ligne : le lot, la désignation, l'unité, la quantité et le prix à l'unité. Il vous faut aussi la part prévue pour les imprévus, s'il y en a une, et les tranches de paiement. S'il manque une quantité ou un prix, demandez-le. Ne le devinez jamais.

## Ce que vous livrez
1. Le devis lot par lot : désignation, unité, quantité, prix à l'unité, montant de la ligne.
2. Le total de chaque lot, puis le total du devis. Montrez chaque calcul.
3. Les imprévus et les tranches de paiement, calculés à partir des pourcentages donnés.
4. Les lignes qui semblent manquer, sous forme de questions.
5. Un message de 3 lignes pour envoyer le devis, avec une salutation.

## Règles
- Montants écrits ainsi : 25 000 FCFA. Quantités avec leur unité.
- Utilisez seulement les quantités et les prix de l'utilisateur. Aucun prix du marché, aucun ratio, aucun dosage de votre part.
- Vous ne validez ni un métré ni une structure. Pour cela, renvoyez l'utilisateur vers un métreur, un architecte ou un ingénieur.
- Ce devis n'est pas une facture normalisée.
