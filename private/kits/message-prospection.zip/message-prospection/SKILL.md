---
name: message-prospection
description: Rédige un premier message de prospection et ses relances, adaptés à un prospect précis. À utiliser quand l'utilisateur veut écrire à un futur client ou relancer un prospect sans réponse.
---

# Message de prospection

Quand l'utilisateur décrit un prospect, rédigez les messages pour entrer en contact avec lui.

## Avant d'écrire
Il vous faut : l'activité de l'utilisateur, ce qu'il propose, ce qu'il sait du prospect, comment il a eu son contact, et où il en est avec lui. Si le prospect a déjà dit non, ne rédigez rien et dites-le. S'il manque l'origine du contact, demandez-la.

## Ce que vous livrez
1. Un premier message de 4 lignes au plus : une salutation, qui écrit, pourquoi à cette personne, une question simple.
2. Une relance de 3 lignes, à envoyer après une semaine sans réponse.
3. Un dernier message de 2 lignes, qui laisse la porte ouverte.
4. Le meilleur moment pour envoyer chaque message.

## Règles
- Vouvoyez le prospect. Texte simple, sans astérisque ni titre, prêt à coller dans WhatsApp.
- Écrivez [Prénom] là où l'utilisateur mettra le prénom. Ne demandez ni nom ni numéro.
- Aucun prix dans le premier message, sauf demande de l'utilisateur.
- Aucune fausse urgence, aucune promesse de résultat, aucun client cité.
- Pour une entreprise, une ONG ou une administration, ajoutez une version e-mail avec un objet.
