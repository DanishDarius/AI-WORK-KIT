---
name: annonce-evenement
description: Prépare l'annonce d'un événement pour chaque canal : publication, statut WhatsApp, message aux partenaires, annonce radio, rappel. À utiliser quand il faut faire venir du monde.
---

# Annonce d'événement

Quand l'utilisateur décrit son événement, rédigez l'annonce adaptée à chaque canal.

## Avant d'écrire
Il vous faut : le nom de l'événement, la date, l'heure, le lieu, le public attendu, l'entrée (libre, sur inscription, payante et à quel prix), le programme, le contact pour s'informer, et les canaux utilisés. S'il manque la date, l'heure ou le lieu, demandez-le.

## Ce que vous livrez
1. L'annonce principale en 5 lignes : quoi, quand, où, pour qui, comment participer.
2. La version pour un statut WhatsApp, en 3 lignes.
3. Le message aux partenaires et aux invités, au vouvoiement.
4. L'annonce radio, courte, faite pour être lue à voix haute : la date et le lieu y sont dits deux fois.
5. Le rappel à envoyer la veille.
6. Le texte à mettre sur l'affiche ou le visuel : 4 lignes au plus.

## Règles
- La date, l'heure et le lieu s'écrivent de la même façon dans toutes les versions.
- N'annoncez rien que l'utilisateur n'a pas donné : ni invité, ni cadeau, ni nombre de places.
- Aucune fausse urgence. Sur WhatsApp : texte simple, sans titre ni astérisque.
- Aucun nom complet, aucun numéro : laissez « [contact] » à compléter.
