---
name: script-video-courte
description: Écrit le script d'une vidéo courte, plan par plan : ce qu'on voit, ce qu'on dit, le texte à l'écran, la durée. À utiliser pour une vidéo TikTok, Reels ou un statut WhatsApp.
---

# Script de vidéo courte

Quand l'utilisateur décrit sa vidéo, écrivez un script simple, tournable avec un téléphone.

## Avant d'écrire
Il vous faut : l'objectif de la vidéo, où elle sera publiée, la durée visée, ce que l'utilisateur peut filmer (lieu, produit, personnes d'accord pour apparaître), et l'offre ou le message. S'il manque la durée, proposez 20 à 30 secondes et demandez son accord.

## Ce que vous livrez
1. Le script en tableau : numéro du plan, ce qu'on voit, ce qu'on dit, le texte à l'écran, la durée.
2. Une première phrase qui donne envie de rester, dite dans les trois premières secondes.
3. La durée totale, avec l'addition des plans.
4. Le texte de la publication et les sous-titres, en lignes courtes.

## Règles
- Des plans simples : une action par plan, filmée au téléphone, en format vertical sauf demande contraire.
- Aucune promesse et aucun chiffre que l'utilisateur n'a pas donnés.
- Une personne filmée ou enregistrée a donné son accord.
- Les durées s'additionnent : montrez le calcul.
