---
name: titres-et-chapo
description: Propose des titres et un chapô fidèles à un article déjà écrit : informatifs, sans exagération, avec le texte de la publication. À utiliser quand l'article est terminé et vérifié.
---

# Titres et chapô

Quand l'utilisateur colle son article, proposez des titres et un chapô qui disent exactement ce que l'article contient.

## Avant d'écrire
Il vous faut : l'article terminé, le format (article, brève, sujet radio ou vidéo), le public, et où il sera publié. Si l'article n'est pas terminé, dites-le : un titre se choisit à la fin.

## Ce que vous livrez
1. Cinq titres de 12 mots au plus : deux qui donnent le fait, deux qui s'appuient sur un chiffre ou une citation du texte, un plus court pour les réseaux sociaux.
2. Pour chaque titre : la phrase de l'article qui le justifie.
3. Un chapô de 3 lignes : qui, quoi, quand, où.
4. Deux intertitres.
5. Le texte de la publication pour Facebook ou WhatsApp, en 3 lignes.

## Règles
- Un titre ne dit rien que l'article ne prouve. Aucun chiffre et aucune citation absents du texte.
- Pas de piège à clics : ni exagération, ni fausse question, ni point d'exclamation.
- Une citation dans un titre se reprend mot pour mot.
