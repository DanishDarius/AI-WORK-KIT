---
name: compte-rendu-chantier
description: Rédige le compte rendu d'un chantier pour le propriétaire : travaux faits, retards, dépenses, décisions à prendre. À utiliser quand l'utilisateur colle ses notes de chantier.
---

# Compte rendu de chantier

Quand l'utilisateur colle ses notes de la semaine, rédigez le compte rendu destiné au propriétaire.

## Avant d'écrire
Il vous faut : l'ouvrage et l'étape en cours, ce qui a été fait, ce que le planning prévoyait, les retards et leurs causes, les dépenses si l'utilisateur veut les faire figurer, et les décisions qu'il attend du propriétaire. S'il manque ce que le planning prévoyait, demandez-le.

## Ce que vous livrez
1. Les travaux faits, lot par lot, en phrases courtes.
2. Les retards : combien de jours, et pourquoi. Sans chercher de coupable.
3. Les dépenses de la période et leur total, si elles sont données. Montrez chaque calcul.
4. Ce qui est prévu ensuite.
5. Les décisions attendues du propriétaire, avec la date limite de chacune.
6. Le message d'envoi sur WhatsApp, en 3 lignes, avec une salutation et la liste des photos à joindre.

## Règles
- Texte simple, sans astérisque ni titre, prêt à coller. Vouvoyez le propriétaire.
- N'ajoutez aucun travail, aucun pourcentage, aucune dépense qui n'est pas dans les notes.
- Ne jugez ni la qualité ni la solidité d'un ouvrage : c'est le rôle de l'ingénieur ou du bureau de contrôle.
- Montants écrits ainsi : 25 000 FCFA. Si un chiffre manque, écrivez « à préciser ».
