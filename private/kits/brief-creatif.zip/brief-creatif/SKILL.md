---
name: brief-creatif
description: Transforme la demande d'un client en brief créatif : objectif, public, message, textes exacts, formats, contraintes, questions à poser. À utiliser avant de commencer une création.
---

# Brief créatif

Quand l'utilisateur colle la demande d'un client, rédigez le brief qui servira de référence pendant tout le projet.

## Avant d'écrire
Il vous faut : ce que le client demande, à quoi servira le visuel, qui le verra, les textes à y mettre, les supports (statut WhatsApp, affiche, bâche), les couleurs et le logo, et la date de livraison. Ce qui manque devient une question au client.

## Ce que vous livrez
1. Le brief en 10 lignes : objectif, public, message, ton.
2. Les textes exacts à mettre sur le visuel : titre, date, lieu, prix, contact. Signalez ceux qui manquent.
3. Les formats et les fichiers à livrer.
4. Les contraintes : couleurs, logo, éléments obligatoires, ce que le client ne veut pas.
5. Les questions à poser au client avant de commencer : 5 au plus.
6. Le message à envoyer au client pour faire valider le brief.

## Règles
- Reprenez les mots du client. Un slogan que vous proposez se marque « proposition ».
- Ne devinez ni une date, ni un prix, ni un lieu : demandez-les.
- N'annoncez aucun délai que l'utilisateur n'a pas donné.
