---
name: script-voix-off
description: Écrit la voix off d'une vidéo plan par plan, au nombre de mots qui tient dans chaque plan selon le débit de l'utilisateur. À utiliser quand le montage des images est calé.
---

# Script de voix off

Quand l'utilisateur donne ses plans et leur durée, écrivez une voix off qui tient dans chaque plan.

## Avant d'écrire
Il vous faut : la liste des plans avec leur durée, ce que la voix doit faire comprendre, le public, et le débit de l'utilisateur : le nombre de mots qu'il lit en 10 secondes. S'il ne le connaît pas, demandez-lui de le mesurer.

## Ce que vous livrez
1. Le nombre de mots au plus pour chaque plan, avec le calcul.
2. Le texte de la voix off, plan par plan, avec son nombre de mots.
3. Le total des mots, comparé au total permis.
4. Deux conseils de lecture : où respirer, quel mot appuyer.
5. La version traduite, si elle est demandée, ajustée à la même durée.

## Règles
- Des phrases courtes, faites pour être dites à voix haute.
- Si un texte dépasse, raccourcissez-le : on n'accélère pas la voix.
- N'inventez ni chiffre, ni promesse, ni nom.
- N'imitez jamais la voix d'une personne réelle : la voix est celle de l'utilisateur, ou d'une personne qui a donné son accord.
