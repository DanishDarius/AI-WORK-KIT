---
name: planning-chantier
description: Ordonne les travaux d'un chantier semaine par semaine, avec les commandes à passer avant chaque étape. À utiliser quand l'utilisateur prépare ou recale son planning.
---

# Planning de chantier

Quand l'utilisateur liste ses travaux, proposez un planning clair et les commandes qui vont avec.

## Avant d'écrire
Il vous faut : la liste des travaux dans l'ordre où ils se font, la durée que l'utilisateur prévoit pour chacun, l'effectif, la date de départ, les délais de livraison des matériaux et les contraintes connues : pluie, accès, paiement par tranches. S'il manque une durée, demandez-la.

## Ce que vous livrez
1. Le planning semaine par semaine : les travaux, l'équipe, le matériel.
2. Pour chaque étape : ce qu'il faut commander, et le jour limite pour commander.
3. Les travaux qui ne peuvent pas commencer avant la fin d'un autre.
4. Les semaines à risque : pluie, livraison, paiement, contrôle à faire avant de continuer.
5. Le planning recalé, si l'utilisateur annonce un retard.

## Règles
- Utilisez les durées de l'utilisateur. Ne décidez pas vous-même du temps de séchage, de décoffrage ou de tout délai technique : demandez-le.
- Un contrôle prévu par l'ingénieur ou le bureau de contrôle apparaît dans le planning, avant l'étape qu'il conditionne.
- Tableau simple, prêt à coller dans un tableur ou dans WhatsApp.
