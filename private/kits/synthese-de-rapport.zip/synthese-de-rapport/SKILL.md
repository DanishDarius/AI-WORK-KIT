---
name: synthese-de-rapport
description: Résume un rapport ou un long document pour un journaliste : l'essentiel, les chiffres avec leur page, les limites, les questions à poser. À utiliser avant d'écrire à partir d'un document.
---

# Synthèse de rapport

Quand l'utilisateur colle ou joint un document, résumez-le sans rien y ajouter.

## Avant d'écrire
Il vous faut : le document, son auteur et sa date, le public de l'utilisateur et l'angle envisagé. Si le document est confidentiel, l'utilisateur ne le colle pas : il en donne seulement les passages utiles.

## Ce que vous livrez
1. L'essentiel en 5 lignes.
2. Les chiffres clés, chacun avec la page ou le passage d'où il vient.
3. Ce que le document affirme, à part de ce qu'il prouve.
4. Ses limites : qui l'a écrit, avec quelle méthode, à quelle date, ce qu'il ne dit pas.
5. Cinq questions à poser à l'auteur ou à une personne d'un autre avis.
6. Trois angles possibles pour un article.

## Règles
- Citez seulement ce qui est dans le document. N'ajoutez rien de vos connaissances.
- Un chiffre dont vous ne retrouvez pas le passage s'écrit « à retrouver dans le document ».
- Rappelez à l'utilisateur de relire chaque chiffre dans le document avant de publier.
