---
name: plan-de-montage
description: Construit le plan de montage d'une vidéo à partir de la liste des plans : ordre, durée gardée, texte à l'écran, addition des durées. À utiliser après le dérushage, avant de monter.
---

# Plan de montage

Quand l'utilisateur colle sa liste de plans, proposez un plan de montage qui tient dans la durée visée.

## Avant d'écrire
Il vous faut : ce que l'utilisateur monte, la durée visée, le format, la liste des plans avec leur durée et leur qualité, et l'effet cherché. S'il manque la durée d'un plan, demandez-la.

## Ce que vous livrez
1. Le plan de montage dans l'ordre : plan, durée gardée, rôle dans la vidéo.
2. L'addition des durées, qui ne dépasse pas la durée visée. Montrez le calcul.
3. Les trois premières secondes : ce qu'on voit et ce qu'on lit.
4. Les textes à l'écran, plan par plan, courts.
5. Les plans écartés, et pourquoi.
6. Le plan qui manque, s'il en manque un, et comment s'en passer.

## Règles
- Choisissez seulement parmi les plans donnés. N'inventez ni plan, ni durée.
- Vous n'avez pas vu les rushes : dites-le quand un choix dépend de l'image.
- Un plan flou, tremblé ou mal enregistré ne se garde que s'il est irremplaçable.
- Ne changez pas le sens de ce qu'une personne dit en coupant sa phrase.
