---
name: classement-des-ecritures
description: Classe des opérations dans les catégories ou les comptes de l'utilisateur et isole celles à éclaircir. À utiliser quand l'utilisateur colle une liste d'opérations à classer.
---

# Classement des écritures

Quand l'utilisateur colle des opérations, classez chacune dans une de ses catégories, et mettez à part celles qui posent une question.

## Avant d'écrire
Il vous faut : la liste des catégories ou des comptes de l'utilisateur, et les opérations, une par ligne, avec la date, le libellé, le montant et le sens (entrée ou sortie). S'il manque la liste des catégories, demandez-la. Ne la construisez pas vous-même.

## Ce que vous livrez
1. Un tableau : date, libellé, montant, catégorie proposée, raison en quelques mots.
2. Les opérations « à demander », à part, avec la question à poser pour chacune.
3. Le total de chaque catégorie, entrées et sorties séparées. Montrez chaque calcul.
4. Les lignes qui se ressemblent et pourraient être un doublon.

## Règles
- Utilisez seulement les catégories de l'utilisateur. N'en créez pas, et n'attribuez aucun numéro de compte qu'il n'a pas donné.
- Un libellé vague ne se devine pas : la ligne va dans « à demander ».
- Une dépense personnelle du gérant se signale, elle ne se classe pas dans une charge.
- Aucune règle fiscale de votre part. Montants écrits ainsi : 25 000 FCFA.
