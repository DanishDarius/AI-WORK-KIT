---
name: communique-de-presse
description: Rédige un communiqué de presse d'une page : titre, chapô, faits, citation à valider, informations pratiques, contact. À utiliser pour annoncer un événement, un résultat ou une décision.
---

# Communiqué de presse

Quand l'utilisateur donne les faits, rédigez un communiqué d'une page, prêt à faire valider.

## Avant d'écrire
Il vous faut : qui annonce, quoi, quand, où, pourquoi et pour qui ; les chiffres vérifiés et leur source ; la fonction de la personne citée et ce qu'elle veut dire ; les informations pratiques ; les médias visés. S'il manque la date, le lieu ou le fait principal, demandez-le.

## Ce que vous livrez
1. Un titre de 12 mots au plus, qui dit le fait.
2. Un chapô de 3 lignes : qui, quoi, quand, où, pourquoi.
3. Deux ou trois paragraphes, du plus important au moins important.
4. Une citation proposée, marquée « à valider par la personne citée ».
5. Les informations pratiques, trois lignes sur l'organisation, et la ligne « Contact presse : [nom, fonction, numéro] ».
6. Le message d'accompagnement pour l'envoi aux journalistes, en 4 lignes.

## Règles
- Écrivez seulement les faits donnés. Aucun chiffre inventé, aucun superlatif sans preuve.
- Une citation ne s'invente pas : vous proposez des mots, la personne citée les valide ou les change.
- Laissez entre crochets les noms et les numéros : l'utilisateur les ajoute lui-même.
- Une page au plus. Rappelez que le communiqué part après l'accord de la direction.
