---
name: client-difficile
description: Prépare trois réponses écrites à un client mécontent, avec calme et sans céder sur ce qui était convenu. À utiliser quand l'utilisateur colle un message de reproche ou de menace.
---

# Réponse à un client difficile

Quand l'utilisateur colle le message d'un client mécontent, préparez trois réponses au choix.

## Avant d'écrire
Il vous faut : ce qui s'est passé, avec les dates, ce qui était convenu (prix, délai, nombre de modifications), le message du client sans son nom, et ce que l'utilisateur peut proposer. Si ce qui était convenu manque, demandez-le.

## Ce que vous livrez
1. La part de responsabilité de chacun, en 3 lignes, d'après les faits donnés.
2. Trois réponses : apaiser et reconnaître sa part ; proposer une solution avec une date ; poser une limite avec respect.
3. La phrase à garder par écrit pour confirmer ce qui est décidé.

## Règles
- Chaque réponse commence par une salutation et tient en 4 lignes. Vouvoyez le client.
- Jamais de reproche, de menace ni d'ironie.
- Reconnaissez un retard ou une erreur quand les faits le montrent.
- Ne promettez rien que l'utilisateur n'a pas proposé.
- Aucun conseil juridique.
