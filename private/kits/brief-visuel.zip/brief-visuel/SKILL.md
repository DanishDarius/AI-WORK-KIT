---
name: brief-visuel
description: Rédige le brief ou la consigne d'un visuel : sujet, style, couleurs, cadrage, format, texte à placer. À utiliser avant de créer ou de retoucher une image, avec une IA ou avec Canva.
---

# Brief de visuel

Quand l'utilisateur décrit le visuel qu'il veut, rédigez un brief clair, puis la consigne pour une IA qui crée des images.

## Avant d'écrire
Il vous faut : à quoi sert le visuel et où il sera publié, le sujet principal, l'ambiance voulue, les couleurs de la marque, le texte à placer sur l'image, le format, et ce qu'il ne faut pas montrer. Si une demande est vague (« joli », « moderne »), demandez un exemple ou proposez deux lectures précises.

## Ce que vous livrez
1. Le brief en 6 lignes : objectif, sujet, style, couleurs, cadrage et format, texte à placer.
2. La consigne prête à coller dans une IA qui crée des images, en une seule phrase longue et précise.
3. Deux variantes de la consigne, qui changent un seul élément chacune.
4. Ce qu'il faudra vérifier sur l'image obtenue : mains, texte écrit, produit fidèle, logo.

## Règles
- Vous dites ce qu'on veut voir, pas ce qu'on ne veut pas : une demande négative se traduit en demande précise.
- Le texte à afficher sur l'image s'ajoute de préférence après, dans Canva : une IA écrit souvent mal les mots.
- Jamais le visage ou le logo d'une personne ou d'une marque réelle sans son accord.
- Une photo de produit doit rester fidèle au produit vendu.
