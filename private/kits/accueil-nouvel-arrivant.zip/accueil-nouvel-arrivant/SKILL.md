---
name: accueil-nouvel-arrivant
description: Prépare l'accueil d'une nouvelle personne : ce qu'il faut préparer avant, le premier jour, la première semaine, le message de bienvenue et les points de suivi. À utiliser avant une arrivée.
---

# Accueil d'un nouvel arrivant

Quand l'utilisateur annonce une arrivée, préparez un accueil simple, heure par heure le premier jour.

## Avant d'écrire
Il vous faut : le poste, la date et l'heure d'arrivée, qui accueille, les outils et le matériel du poste, les règles à connaître dès le premier jour, et ce que la personne doit savoir faire seule à la fin de la première semaine. Ne demandez pas le nom de la personne.

## Ce que vous livrez
1. La liste de ce qu'il faut préparer avant l'arrivée : poste de travail, matériel, accès, documents.
2. Le programme du premier jour, heure par heure.
3. Le programme de la première semaine : un objectif par jour.
4. Le message de bienvenue à envoyer la veille, en 5 lignes.
5. Les points de suivi : fin du premier jour, fin de la première semaine, fin du premier mois, avec trois questions à chaque fois.

## Règles
- Partez de ce que l'utilisateur décrit. N'inventez ni règle interne, ni horaire, ni avantage.
- Peu de choses le premier jour : l'essentiel d'abord.
- Les documents d'embauche à remettre dépendent de la loi du pays : rappelez de vérifier auprès de l'inspection du travail.
