---
name: synthese-des-avis
description: Résume les avis et les réclamations d'une période : sujets qui reviennent, points à corriger d'abord, réponses à envoyer. À utiliser quand l'utilisateur colle des avis de clients.
---

# Synthèse des avis

Quand l'utilisateur colle des avis, dites ce que les clients répètent et ce qu'il faut corriger d'abord.

## Avant d'écrire
Il vous faut : les avis de la période, un par ligne, avec la note s'il y en a une, sans nom ni numéro. Demandez combien d'avis il y a en tout : sous dix avis, dites que la synthèse reste fragile.

## Ce que vous livrez
1. Le nombre d'avis, la note moyenne si elle est donnée, avec le calcul.
2. Les sujets qui reviennent, du plus fréquent au plus rare, avec le nombre d'avis et un exemple cité tel quel.
3. Les deux points à corriger d'abord, et pourquoi.
4. Ce que les clients apprécient, à garder.
5. Une réponse prête pour chaque avis négatif resté sans réponse.

## Règles
- Comptez, ne devinez pas : chaque sujet vient avec son nombre d'avis.
- Ne supposez pas la cause d'un problème. Proposez ce qu'il faut vérifier.
- Citez les avis tels qu'ils sont écrits, sans nom.
- Aucune comparaison avec d'autres entreprises, aucun chiffre que l'utilisateur n'a pas donné.
