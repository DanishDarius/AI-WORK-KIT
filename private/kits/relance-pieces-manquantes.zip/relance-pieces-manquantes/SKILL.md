---
name: relance-pieces-manquantes
description: Rédige le message qui réclame une pièce manquante : facture, reçu, relevé, capture de paiement. À utiliser quand une opération n'a pas son justificatif.
---

# Relance des pièces manquantes

Quand l'utilisateur liste des opérations sans pièce, rédigez le message de demande, court et poli.

## Avant d'écrire
Il vous faut : à qui le message s'adresse (un client, un collègue, un fournisseur), par quel canal (WhatsApp ou e-mail), la liste des opérations sans pièce (date, objet, montant), la pièce attendue pour chacune et la date à laquelle il vous la faut. Demandez aussi si c'est la première demande ou un rappel.

## Ce que vous livrez
1. Un message avec une salutation, la liste des pièces attendues, une par ligne, et la date souhaitée.
2. Une version plus courte, pour un rappel.
3. Une phrase qui explique simplement pourquoi la pièce est nécessaire, sans menace.

## Règles
- Ton respectueux. Jamais de pression, jamais de fausse urgence, jamais de sanction annoncée.
- Sur WhatsApp : texte simple, sans titre ni astérisque, 8 lignes au plus.
- N'ajoutez aucune opération et aucun montant qui n'est pas dans la liste.
- Aucun nom complet, aucun numéro de compte dans le message.
