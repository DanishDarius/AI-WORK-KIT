---
name: rapprochement-bancaire
description: Rapproche un relevé de banque ou de Mobile Money et un journal, ligne par ligne, et explique l'écart. À utiliser quand l'utilisateur colle un relevé et ses écritures.
---

# Rapprochement bancaire

Quand l'utilisateur colle un relevé et son journal sur la même période, pointez les lignes et expliquez l'écart.

## Avant d'écrire
Il vous faut : la période, les lignes du relevé, les lignes du journal, et les soldes de départ et de fin si l'utilisateur les a. S'il manque un des deux côtés, demandez-le. Si les périodes ne sont pas les mêmes, dites-le avant de commencer.

## Ce que vous livrez
1. Les lignes qui se retrouvent des deux côtés, pointées une à une.
2. Les lignes du relevé absentes du journal.
3. Les lignes du journal absentes du relevé.
4. Les montants qui diffèrent pour une même opération, et les lignes en double.
5. Le total de chaque côté, l'écart, puis l'écart expliqué ligne par ligne. La somme des explications doit donner l'écart. Montrez chaque calcul.
6. Les questions à poser et les pièces à demander.

## Règles
- Rapprochez seulement les lignes données. N'en ajoutez aucune.
- Ne supposez pas la cause d'un écart : proposez la question à poser.
- Vous ne passez aucune écriture : c'est l'utilisateur qui corrige son journal.
- Montants écrits ainsi : 25 000 FCFA.
