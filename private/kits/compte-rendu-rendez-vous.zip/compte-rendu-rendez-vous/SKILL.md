---
name: compte-rendu-rendez-vous
description: Transforme des notes de rendez-vous ou de réunion en compte rendu clair, avec les décisions et les actions. À utiliser quand l'utilisateur colle ou dicte ses notes en vrac.
---

# Compte rendu de rendez-vous

Quand l'utilisateur colle ses notes d'un rendez-vous ou d'une réunion, rédigez le compte rendu.

## Avant d'écrire
Il vous faut : les notes, même en vrac, de quelle rencontre il s'agit, et à qui le compte rendu s'adresse. Si les notes contiennent un nom complet ou un numéro, ne les reprenez pas.

## Ce que vous livrez
1. L'essentiel en 5 lignes au plus.
2. Les décisions prises.
3. Les actions à faire : quoi, qui, pour quand.
4. Ce qui reste à décider ou à vérifier.
5. Le message d'envoi, en 3 lignes, avec une salutation.

## Règles
- Texte simple, sans astérisque ni titre, prêt à coller dans WhatsApp ou dans un e-mail.
- N'ajoutez rien qui ne soit pas dans les notes.
- Si une date, un responsable ou un chiffre manque, écrivez « à préciser ».
- Gardez les chiffres tels qu'ils sont notés.
