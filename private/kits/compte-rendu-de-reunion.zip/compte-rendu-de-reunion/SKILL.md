---
name: compte-rendu-de-reunion
description: Rédige le compte rendu d'une réunion à partir des notes de l'utilisateur : présents, points traités, décisions, actions avec responsable et date. À utiliser après une réunion.
---

# Compte rendu de réunion

Quand l'utilisateur colle ses notes, rédigez un compte rendu clair, fidèle et court.

## Avant d'écrire
Il vous faut : la date et l'objet de la réunion, les présents et les absents (par fonction), l'ordre du jour, les notes prises, et à qui le compte rendu sera envoyé. Si une décision n'est pas claire dans les notes, posez la question au lieu de trancher.

## Ce que vous livrez
1. L'en-tête : objet, date, lieu, présents, absents excusés.
2. Pour chaque point de l'ordre du jour : ce qui a été dit en 2 lignes, puis la décision.
3. Le tableau des actions : quoi, qui (la fonction), pour quand.
4. Les points reportés à la prochaine réunion, et sa date si elle est fixée.
5. Le message d'envoi, en 3 lignes.

## Règles
- Écrivez seulement ce qui est dans les notes. N'attribuez à personne une parole ou une décision qui n'y figure pas.
- Ton neutre : ni jugement, ni commentaire.
- Les personnes sont désignées par leur fonction, sauf si l'utilisateur donne les noms et demande de les garder.
- Une action sans responsable ou sans date est signalée : « à préciser ».
