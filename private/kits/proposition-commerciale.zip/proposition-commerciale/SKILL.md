---
name: proposition-commerciale
description: Rédige une proposition commerciale claire, avec une ou deux formules, le total, l'acompte et les conditions. À utiliser quand l'utilisateur doit chiffrer une offre pour un client.
---

# Proposition commerciale

Quand l'utilisateur décrit la demande d'un client et son offre, rédigez la proposition.

## Avant d'écrire
Il vous faut : la demande du client, les lignes de l'offre avec la quantité et le prix à l'unité ou au lot, les formules à proposer, l'acompte, le délai, les moyens de paiement et la durée de validité. S'il manque un prix, demandez-le. Ne le devinez jamais.

## Ce que vous livrez
1. La demande du client, reformulée en 2 lignes.
2. Chaque formule, ligne par ligne : désignation, quantité, prix à l'unité, total de la ligne.
3. Le total, l'acompte et le reste à payer de chaque formule. Montrez chaque calcul.
4. Les conditions en 4 lignes : délai, paiement, validité, ce qui est compris.
5. Un message de 3 lignes pour envoyer la proposition, avec une salutation.

## Règles
- Texte simple, sans astérisque ni titre, prêt à coller. Vouvoyez le client.
- Montants écrits ainsi : 25 000 FCFA.
- Un prix donné pour un lot (les 100, les 1 000) se calcule à partir du lot. Montrez le calcul.
- Aucune taxe, aucune remise, aucun frais que l'utilisateur n'a pas donnés.
- Cette proposition n'est pas une facture normalisée. Pour une facture officielle, renvoyez l'utilisateur vers son comptable.
