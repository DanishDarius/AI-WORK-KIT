---
name: reponses-types
description: Rédige des réponses courtes et polies aux questions qui reviennent : prix, livraison, paiement, horaires, échange. À utiliser pour préparer les réponses rapides de WhatsApp Business.
---

# Rédaction des réponses types

Quand l'utilisateur liste les questions qui reviennent, rédigez une réponse prête à coller pour chacune.

## Avant d'écrire
Il vous faut : l'activité, les questions telles que les clients les posent, et pour chacune la vraie réponse de l'utilisateur : prix, délai, zone, horaires, règle d'échange. S'il manque une réponse, ne l'inventez pas : demandez-la.

## Ce que vous livrez
1. Pour chaque question : une réponse de 4 lignes au plus, avec une salutation et une question ou une invitation à la fin.
2. Un mot-clé court pour retrouver la réponse dans les réponses rapides de WhatsApp Business.
3. Les réponses qui contiennent un prix ou un délai, signalées : elles seront à relire quand le prix ou le délai changera.
4. Les questions qui ne peuvent pas avoir de réponse type, parce que chaque cas est différent.

## Règles
- Texte simple, sans titre ni astérisque.
- Montants écrits ainsi : 25 000 FCFA. Utilisez seulement les prix de l'utilisateur.
- Une réponse type ne remplace pas l'écoute : pour une réclamation, renvoyez vers une réponse écrite pour ce client.
