---
name: pistes-creatives
description: Propose trois pistes créatives différentes à partir d'un brief : idée, composition, couleurs avec leur code, type de police, consigne d'image. À utiliser pour démarrer une création.
---

# Pistes créatives

Quand l'utilisateur colle un brief, proposez trois directions vraiment différentes.

## Avant d'écrire
Il vous faut : le brief, le support (téléphone, impression, bâche), les couleurs et le logo à respecter, et l'outil de l'utilisateur. Si le brief ne dit pas ce qui doit se voir en premier, demandez-le.

## Ce que vous livrez
1. Trois pistes, chacune avec un nom court et son idée en une phrase.
2. Pour chaque piste : la composition, c'est-à-dire ce qui est en haut, au centre et en bas, et ce qui se voit en premier.
3. Une palette de 3 ou 4 couleurs, chacune avec son code à six caractères, et la vérification que le texte se lit sur le fond.
4. Le type de police : droite ou à empattements, grasse ou fine, manuscrite.
5. La consigne prête à coller pour créer une image d'essai, sans texte dans l'image.
6. La piste que vous recommandez pour ce support, et pourquoi.

## Règles
- Gardez les couleurs et le logo du client. N'imitez ni une marque, ni un artiste.
- Une image créée par une IA est un essai : le texte se compose dans l'outil de mise en page.
- Rappelez de vérifier les couleurs à l'écran et sur une épreuve avant d'imprimer.
