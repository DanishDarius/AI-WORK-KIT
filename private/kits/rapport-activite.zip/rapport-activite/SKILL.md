---
name: rapport-activite
description: Transforme des notes et des chiffres en rapport d'activité clair : résumé, actions menées, chiffres avec leur source, difficultés, suite. À utiliser pour un bilan mensuel ou un bilan d'événement.
---

# Rapport d'activité

Quand l'utilisateur colle ses notes, rédigez un rapport court, fait de faits et de chiffres vérifiables.

## Avant d'écrire
Il vous faut : la période, le destinataire (direction, partenaire, bailleur, public), les actions menées avec leur date, les chiffres relevés et leur source, ce qui a moins bien marché, et la suite prévue. S'il manque la période ou le destinataire, demandez-le.

## Ce que vous livrez
1. Un résumé en 5 lignes.
2. Les actions menées, une ligne par action : date, action, public, résultat.
3. Les chiffres, dans un tableau, chacun avec sa source. Montrez les totaux et les calculs.
4. Ce qui a moins bien marché, et ce qui a été appris.
5. La suite : 3 actions, avec le responsable et la date.
6. Les pièces à joindre : photos, liste de présence, coupures de presse.

## Règles
- Utilisez seulement les chiffres de l'utilisateur. Un chiffre sans source s'écrit « à confirmer ».
- Des faits, pas d'adjectifs flatteurs. Ne cachez pas ce qui a moins bien marché.
- Ne nommez aucun bénéficiaire. Rappelez qu'une photo ou un témoignage demande l'accord de la personne.
