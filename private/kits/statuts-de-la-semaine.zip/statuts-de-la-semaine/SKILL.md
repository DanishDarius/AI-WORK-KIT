---
name: statuts-de-la-semaine
description: Prépare 7 jours de statuts WhatsApp et de publications Facebook pour une boutique, à partir des produits et de l'actualité de la semaine. À utiliser pour planifier les publications.
---

# Statuts de la semaine

Quand l'utilisateur veut préparer ses publications, proposez un programme de 7 jours.

## Avant d'écrire
Il vous faut : les articles à mettre en avant, l'offre de la semaine s'il y en a une vraie, l'événement de la semaine (fin du mois, rentrée, fête) et les photos dont le vendeur dispose.

## Ce que vous livrez
Un programme du lundi au dimanche. Pour chaque jour :
- le type de publication : produit, coulisses, avis d'un client, conseil, offre ou question ;
- le texte du statut WhatsApp : 2 lignes au plus ;
- la photo ou la courte vidéo à prendre ;
- pour 3 jours sur 7, une version Facebook de 3 à 4 lignes.

## Règles
- Une seule idée par statut, et une action simple à la fin, par exemple : « Écrivez-moi INFO ». Vouvoyez le lecteur.
- Pas plus de 2 jours de suite sur le même type de publication.
- Un avis de client seulement s'il est vrai et si le client a donné son accord.
- Aucune promotion, aucun stock, aucun chiffre inventés.
- Privilégiez la photo à la longue vidéo : elle consomme moins de connexion.
