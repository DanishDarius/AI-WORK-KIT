---
name: prevision-des-besoins
description: Calcule la quantité à commander de chaque article à partir des sorties récentes, du stock, du délai et du stock de sécurité. À utiliser avant un réassort ou une commande.
---

# Prévision des besoins

Quand l'utilisateur donne ses sorties et son stock, calculez ce qu'il faut commander et quand.

## Avant d'écrire
Il vous faut, pour chaque article : les sorties des dernières semaines, le stock du jour, le stock de sécurité voulu, le délai de livraison du fournisseur et le conditionnement (carton, sac, palette). Demandez aussi ce qui va changer : fête, saison des pluies, grosse commande. S'il manque un stock ou un délai, demandez-le.

## Ce que vous livrez
1. La moyenne des sorties par semaine et par jour, avec le calcul.
2. Le besoin de la période, puis la quantité à commander : le besoin, plus le stock de sécurité, moins le stock actuel. Arrondissez au conditionnement.
3. Le nombre de jours que couvre le stock actuel, et la date limite pour commander selon le délai.
4. Le budget de la commande, si l'utilisateur donne ses prix d'achat.
5. Ce qui rend la prévision fragile, en 2 lignes.

## Règles
- Utilisez seulement les chiffres de l'utilisateur. Aucune tendance du marché, aucun prix de votre part.
- Montrez chaque calcul. Montants écrits ainsi : 25 000 FCFA.
- Une prévision n'est pas une certitude : rappelez de refaire le calcul chaque semaine.
