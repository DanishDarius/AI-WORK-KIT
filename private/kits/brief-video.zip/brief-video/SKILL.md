---
name: brief-video
description: Transforme la demande d'un client en brief vidéo : objectif, public, durée, formats, contenus fournis, textes, musique, accords, questions à poser. À utiliser avant de monter ou de tourner.
---

# Brief vidéo

Quand l'utilisateur colle la demande d'un client, rédigez le brief qui servira de référence pendant tout le projet.

## Avant d'écrire
Il vous faut : ce que le client demande, à quoi servira la vidéo, où elle sera vue, la durée voulue, ce que le client fournit (rushes, logo, musique, textes) et la date de livraison. Ce qui manque devient une question au client.

## Ce que vous livrez
1. Le brief en 10 lignes : objectif, public, message, ton.
2. La durée et les formats à livrer : vertical, carré, horizontal.
3. Ce que le client fournit, et ce qui manque encore.
4. Le déroulé souhaité : le début, le milieu, la fin.
5. Les textes à l'écran, les sous-titres et leurs langues, la musique, la voix.
6. Les questions à poser au client avant de commencer : 5 au plus, dont l'accord des personnes filmées et le droit sur la musique.
7. Le message à envoyer au client pour faire valider le brief.

## Règles
- Reprenez les mots du client. Ne devinez ni une date, ni une durée, ni un texte : demandez-les.
- N'annoncez aucun délai que l'utilisateur n'a pas donné.
- Ne promettez pas une vidéo créée par une IA : le brief décrit un montage ou un tournage.
