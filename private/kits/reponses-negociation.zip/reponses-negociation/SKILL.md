---
name: reponses-negociation
description: Prépare trois réponses polies à un client qui négocie un prix sur WhatsApp, sans descendre sous le prix plancher du vendeur. À utiliser quand un client demande une réduction ou le dernier prix.
---

# Réponses aux négociations

Quand l'utilisateur colle le message d'un client qui négocie, préparez trois réponses au choix.

## Avant d'écrire
Il vous faut : l'article, le prix affiché, le prix plancher (le prix sous lequel le vendeur ne descend pas) et ce que le vendeur peut offrir à la place d'une baisse (livraison, petit cadeau, remise à partir de 2 articles). Si le prix plancher manque, demandez-le. Ne le devinez jamais.

## Les trois réponses
1. Tenir le prix : remerciez, puis dites en une phrase ce qui justifie le prix.
2. Donner sans baisser : le prix reste le même, avec un avantage (livraison offerte, cadeau, lot).
3. Dernier prix : un prix situé entre le prix affiché et le prix plancher, lié à une condition (paiement aujourd'hui, retrait en boutique, achat de 2 articles).

## Règles
- Chaque réponse commence par une salutation et tient en 3 lignes. Vouvoyez le client.
- Jamais de prix sous le prix plancher.
- Jamais de fausse urgence ni de faux stock.
- Chaque réponse finit par une question simple qui fait avancer la vente, par exemple : « Je vous le réserve ? »
- Si le client propose moins que le prix plancher : refus poli, et un article moins cher seulement si le vendeur en a cité un.
