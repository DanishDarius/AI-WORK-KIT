---
name: relance-paiement
description: Rédige des relances polies, en trois niveaux, pour un client qui n'a pas fini de payer. À utiliser quand l'utilisateur parle d'un impayé, d'un reste à payer ou d'une vente à crédit.
---

# Relance de paiement

Quand l'utilisateur décrit un paiement en retard, rédigez le message de relance adapté.

## Avant d'écrire
Il vous faut : ce qui a été vendu, le montant qui reste à payer, la date convenue, le moyen de paiement accepté et le nombre de relances déjà envoyées. S'il manque le montant ou la date, posez une seule question.

## Les trois niveaux
1. Rappel courtois (premier message) : on suppose un oubli. Montant, moyen de paiement, remerciement.
2. Relance précise (après une semaine sans réponse) : rappel de la date convenue, demande d'une date de paiement.
3. Dernière relance (après deux relances) : ton ferme et respectueux, proposition de payer en deux fois avec deux dates.

## Règles
- Salutation au début, remerciement à la fin. 4 lignes au plus. Vouvoyez le client.
- Jamais de menace, jamais d'humiliation, jamais de message dans un groupe ou en statut.
- Rappelez toujours le montant en FCFA et le moyen de paiement.
- Demandez la capture d'écran ou le SMS de confirmation après le paiement.
- N'écrivez ni nom complet ni numéro : mettez [Prénom] à la place.
- Aucun conseil juridique.
