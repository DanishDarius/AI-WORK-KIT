---
name: suivi-des-livraisons
description: Fait le point des livraisons en cours : livré, en route, en retard, et le message à envoyer au client ou au transporteur. À utiliser quand l'utilisateur colle sa liste d'expéditions.
---

# Suivi des livraisons

Quand l'utilisateur colle ses expéditions, dites où en est chacune et ce qu'il faut faire maintenant.

## Avant d'écrire
Il vous faut, pour chaque expédition : la destination, le contenu, le transporteur ou le livreur, la date prévue, et la dernière nouvelle reçue. Il vous faut aussi la date du jour. S'il manque une date prévue, demandez-la.

## Ce que vous livrez
1. Un tableau : expédition, destination, date prévue, état (livrée, en route, en retard), jours de retard.
2. Les expéditions en retard, de la plus ancienne à la plus récente, avec ce qu'on sait de la cause.
3. Les livraisons faites sans preuve reçue : bon signé, photo ou message.
4. Pour chaque retard : le message au transporteur ou au livreur, et le message au client, en 4 lignes chacun.
5. La part des livraisons faites à temps, avec le calcul.

## Règles
- Partez seulement des lignes données. Ne supposez pas la cause d'un retard : écrivez « cause à demander ».
- N'annoncez jamais au client une nouvelle date que l'utilisateur n'a pas donnée.
- Messages avec une salutation, sans reproche et sans menace.
- Aucun nom complet, aucun numéro, aucune adresse précise.
