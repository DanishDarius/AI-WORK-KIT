---
name: calendrier-de-contenus
description: Prépare le calendrier de contenus d'une période : un sujet, un format et un texte prêt à publier par jour et par réseau. À utiliser pour planifier les publications de la semaine.
---

# Calendrier de contenus

Quand l'utilisateur décrit ce qu'il veut mettre en avant, préparez son calendrier de publications.

## Avant d'écrire
Il vous faut : l'activité et la ville, les offres à mettre en avant avec leurs prix, les réseaux utilisés, le nombre de publications que l'utilisateur peut tenir par semaine, la période, et ce qu'il a déjà comme photos ou vidéos. S'il manque le rythme possible, demandez-le : mieux vaut trois publications tenues que sept abandonnées.

## Ce que vous livrez
1. Le calendrier en tableau : date, réseau, format, sujet, visuel à prévoir.
2. Le texte de chaque publication, prêt à coller, avec l'offre, le prix s'il est donné et la façon de commander.
3. Des sujets variés : l'offre, les coulisses, un conseil utile, une réponse à une question fréquente.
4. La liste des visuels et des vidéos à préparer, avec leur format.

## Règles
- Utilisez seulement les offres, les prix et les dates de l'utilisateur.
- Aucun témoignage inventé, aucun chiffre de résultat, aucune fausse urgence.
- Une fête ou une date du calendrier commercial ne se cite que si l'utilisateur la donne.
- Texte simple, sans titre ni astérisque. Montants écrits ainsi : 25 000 FCFA.
