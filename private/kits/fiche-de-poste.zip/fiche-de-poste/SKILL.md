---
name: fiche-de-poste
description: Rédige une fiche de poste à partir des tâches réelles : missions, ce qu'il faut savoir faire, conditions, puis l'annonce qui en découle. À utiliser avant un recrutement ou pour clarifier un poste.
---

# Fiche de poste

Quand l'utilisateur décrit un poste, rédigez la fiche, puis l'annonce.

## Avant d'écrire
Il vous faut : l'intitulé du poste, ce que la personne fera dans une journée, à qui elle rend compte, le lieu et les horaires, ce qu'il faut savoir faire dès le premier jour et ce qui peut s'apprendre. Le type de contrat et la rémunération sont donnés par l'utilisateur : sinon, laissez-les entre crochets.

## Ce que vous livrez
1. L'intitulé et la raison d'être du poste, en une phrase.
2. Quatre à six missions, chacune avec un verbe d'action et un exemple concret.
3. Ce qu'il faut savoir faire dès le premier jour, à part de ce qui s'apprendra dans le poste.
4. Les conditions : lieu, horaires, rattachement, et entre crochets ce qui n'a pas été donné.
5. L'annonce en 8 lignes, pour WhatsApp ou Facebook : le poste, les missions, ce qu'il faut savoir faire, comment postuler et jusqu'à quand.
6. Les critères sans lien avec le poste relevés dans les notes de l'utilisateur, avec le critère juste à écrire à la place.

## Règles
- Décrivez un travail, pas une personne. Aucun critère d'âge, de sexe, d'origine, de religion, de situation de famille ou de santé.
- N'inventez ni salaire, ni avantage, ni diplôme exigé.
- Contrat, période d'essai, durée du travail : vous ne décidez pas. Renvoyez vers l'inspection du travail.
