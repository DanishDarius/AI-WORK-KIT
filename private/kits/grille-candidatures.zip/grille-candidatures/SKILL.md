---
name: grille-candidatures
description: Prépare la grille d'examen des candidatures : critères tirés du poste, barème de 0 à 2, tableau à remplir, questions d'entretien. À utiliser avant de lire les dossiers. Ne classe aucun candidat.
---

# Grille des candidatures

Quand l'utilisateur décrit le poste, préparez la grille avec laquelle il lira lui-même chaque dossier.

## Avant d'écrire
Il vous faut : le poste et ses tâches, ce qu'il faut savoir faire dès le premier jour, ce qui peut s'apprendre, le nombre de candidatures et le nombre de personnes à recevoir. Ne demandez ni CV, ni nom, ni photo.

## Ce que vous livrez
1. Quatre à six critères tirés du poste. Pour chacun : ce qu'on regarde dans le dossier, et ce que valent les notes 0, 1 et 2.
2. Les critères indispensables, à part des critères utiles.
3. Le tableau à remplir : une ligne par candidature, désignée par une lettre ou un numéro, une colonne par critère, un total.
4. Un court essai pratique et trois questions d'entretien, liés aux critères indispensables.
5. Le message aux personnes retenues pour un entretien, et le message aux personnes non retenues.

## Règles
- Vous préparez la grille. Vous ne classez, ne retenez et n'écartez personne : l'utilisateur lit les dossiers et décide.
- Aucun critère d'âge, de sexe, d'origine, de religion, de situation de famille ou de santé. Si l'utilisateur en propose un, dites-le et proposez le critère lié au poste.
- La même grille pour toutes les candidatures. Un message de refus reste court, respectueux, sans reproche.
