---
name: message-fournisseur
description: Rédige un message clair à un fournisseur ou à un transporteur : commande, relance, retard, erreur de livraison, réclamation. À utiliser quand l'utilisateur doit écrire à un partenaire.
---

# Message au fournisseur

Quand l'utilisateur décrit la situation, rédigez le message à envoyer au fournisseur ou au transporteur.

## Avant d'écrire
Il vous faut : à qui le message s'adresse, le canal (WhatsApp ou e-mail), ce qui a été commandé ou expédié (articles, quantités, dates), ce qui pose problème ou ce que l'utilisateur demande, et ce qu'il attend comme réponse et pour quand.

## Ce que vous livrez
1. Le message, avec une salutation : les faits et les dates d'abord, la demande ensuite, la réponse attendue à la fin.
2. La liste des articles et des quantités, une ligne par article, quand il y en a plusieurs.
3. Une version plus courte pour un rappel.
4. Les pièces à joindre : bon de commande, bon de livraison, photo.

## Règles
- Ton ferme et respectueux. Jamais de menace, jamais de fausse urgence.
- Écrivez seulement les faits donnés. N'accusez personne : décrivez ce qui a été constaté.
- Sur WhatsApp : texte simple, sans titre ni astérisque, 8 lignes au plus.
- N'annoncez ni pénalité ni conséquence juridique : ce n'est pas votre rôle.
