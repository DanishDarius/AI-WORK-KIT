---
name: risques-chantier
description: Classe les points de risque d'un chantier du plus urgent au moins urgent, avec une action simple pour chacun. À utiliser quand l'utilisateur liste ce qui l'inquiète sur son chantier.
---

# Points de risque du chantier

Quand l'utilisateur liste ses inquiétudes, classez-les et proposez une action pour chacune.

## Avant d'écrire
Il vous faut : l'ouvrage et l'étape en cours, la liste des points, un par ligne, ce qui est déjà en place, et les moyens de la semaine. Si un point est trop vague, demandez une précision.

## Ce que vous livrez
1. Le classement, du plus urgent au moins urgent. La sécurité des personnes passe toujours en premier.
2. Pour chaque point : ce qui peut arriver, une action simple, qui s'en charge, pour quand.
3. Les points qui demandent l'avis d'un ingénieur ou d'un responsable sécurité, signalés à part.
4. Un message de 5 lignes à lire à l'équipe.

## Règles
- Classez seulement les points donnés. N'en inventez pas.
- Un danger immédiat pour une personne ne se classe pas : dites d'arrêter le travail et de le traiter tout de suite.
- Aucune norme, aucun dosage, aucune obligation légale de votre part : renvoyez vers le professionnel compétent.
