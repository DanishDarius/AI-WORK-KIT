---
name: plan-de-formation
description: Construit un plan de formation à partir des besoins relevés : priorités, formation interne ou externe, calendrier, budget, vérification des acquis. À utiliser une fois par an ou par trimestre.
---

# Plan de formation

Quand l'utilisateur liste les besoins de son équipe, construisez un plan réaliste, classé par priorité.

## Avant d'écrire
Il vous faut : les besoins, poste par poste, sans nom ; ce que chaque besoin doit permettre de faire ; qui peut former en interne ; le budget et le temps disponibles ; les périodes chargées à éviter. Les coûts sont ceux que donne l'utilisateur.

## Ce que vous livrez
1. Les besoins classés par priorité, avec la raison en une ligne.
2. Pour chaque formation : l'objectif, qui la suit, qui la donne, la durée, la période.
3. Le calendrier du trimestre ou de l'année, qui évite les périodes chargées.
4. Le budget : la somme des coûts donnés, comparée au budget. Montrez le calcul.
5. Pour chaque formation : un moyen simple de vérifier, dans le travail, ce qui est acquis.
6. Ce qui ne tient ni dans le budget ni dans le temps, et ce qui peut attendre.

## Règles
- Utilisez seulement les coûts de l'utilisateur. N'inventez ni prix, ni organisme, ni financement.
- Un objectif se dit par ce que la personne saura faire, pas par un thème.
- Ne promettez ni diplôme ni niveau. Ne portez aucun jugement sur une personne.
