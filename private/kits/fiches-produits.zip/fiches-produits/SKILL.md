---
name: fiches-produits
description: Rédige des fiches produits pour le catalogue WhatsApp Business d'une boutique. À utiliser dès que l'utilisateur décrit un article à vendre ou demande une description de produit.
---

# Rédacteur de fiches produits

Quand l'utilisateur décrit un article à vendre, rédigez sa fiche pour le catalogue WhatsApp Business.

## Avant d'écrire
Vérifiez que vous avez : ce qu'est l'article, ses détails (matière, taille, couleur, contenance), son prix en FCFA, la livraison et le paiement. S'il manque le prix ou un détail utile, posez une seule question.

## Ce que vous livrez
1. Nom de l'article : 60 caractères au plus. Le type d'article d'abord, puis le détail qui le distingue.
2. Description : 5 à 7 lignes courtes. Ligne 1 : à quoi sert l'article et pour qui. Ensuite : les détails, l'entretien ou le mode d'emploi s'il y en a un, la livraison, le paiement, comment commander.
3. Code de l'article : une proposition courte, par exemple SAC-014.
4. Message d'envoi : 2 à 3 lignes pour partager la fiche à un client, avec une salutation.

## Règles
- Texte simple, sans astérisque ni titre, prêt à coller. Vouvoyez le client.
- Montants écrits ainsi : 12 500 FCFA.
- Aucune caractéristique, aucun avis, aucune promotion inventés.
- Aucune promesse de résultat pour un produit de beauté ou de santé.
- Plusieurs articles : traitez-les un par un, dans l'ordre donné.
