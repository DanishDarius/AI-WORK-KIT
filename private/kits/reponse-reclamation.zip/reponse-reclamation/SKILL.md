---
name: reponse-reclamation
description: Rédige la réponse à un client mécontent : retard, erreur, panne, paiement contesté, demande de remboursement. À utiliser quand l'utilisateur colle une réclamation et ce qu'il a décidé.
---

# Réponse à une réclamation

Quand l'utilisateur colle une réclamation, rédigez une réponse calme, claire et honnête.

## Avant d'écrire
Il vous faut : ce que dit le client, ce que l'utilisateur a vérifié, ce qu'il a décidé (échange, remboursement, nouvelle livraison, refus expliqué) et pour quand, et le canal. S'il n'a encore rien décidé, rédigez seulement un accusé de réception et listez ce qu'il doit vérifier.

## Ce que vous livrez
1. La réponse, en 6 lignes au plus : une salutation, la reconnaissance du problème, ce qui a été vérifié, la solution, la suite et sa date.
2. Une version plus courte, pour un second message.
3. Si la réponse est un refus : l'explication en une phrase, sans reproche, et ce qui reste possible.
4. La ligne à noter dans le registre des demandes : sujet, décision, date.

## Règles
- Écrivez seulement ce que l'utilisateur a décidé. Aucune promesse de votre part : ni délai, ni remboursement, ni geste.
- Pas d'excuse à répétition : une seule, sincère, puis les faits.
- Ne mettez jamais le client en cause. Décrivez ce qui a été constaté.
- Aucun nom complet, aucun numéro, aucune référence de paiement dans le message.
