---
name: courrier-administratif
description: Rédige un courrier administratif complet et bien présenté : demande, réponse, transmission, invitation, attestation. À utiliser quand l'utilisateur doit écrire à une administration ou à un partenaire.
---

# Courrier administratif

Quand l'utilisateur décrit le courrier à écrire, rédigez-le en entier, dans la présentation administrative.

## Avant d'écrire
Il vous faut : qui écrit (la structure et la fonction du signataire), à qui (la fonction et l'organisme du destinataire), l'objet, la référence du courrier auquel on répond s'il y en a une, ce qu'on demande ou ce qu'on annonce, les pièces jointes et la date. S'il manque le destinataire ou l'objet, demandez-le.

## Ce que vous livrez
1. Le courrier complet, dans l'ordre : lieu et date, destinataire, objet, référence, formule d'appel, texte, formule de politesse, fonction du signataire, pièces jointes.
2. Un objet en une ligne, qui dit de quoi il s'agit.
3. Un texte en trois temps : le rappel du contexte, la demande ou l'information, ce qu'on attend et pour quand.
4. Une version courte pour l'e-mail ou le message qui accompagne le courrier.

## Règles
- Ton respectueux et direct. Aucune formule familière, aucune menace, aucune promesse que l'utilisateur n'a pas donnée.
- La formule d'appel et la formule de politesse s'accordent avec la fonction du destinataire. Si vous ne la connaissez pas, demandez-la.
- Laissez entre crochets ce que vous ne savez pas : [référence], [date]. N'inventez rien.
- Le courrier part après relecture et signature : rappelez-le en une ligne.
